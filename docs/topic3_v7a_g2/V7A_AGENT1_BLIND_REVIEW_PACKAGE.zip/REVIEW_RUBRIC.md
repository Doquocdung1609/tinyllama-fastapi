# Review rubric

For each question choose SUPPORTED, UNSUPPORTED, AMBIGUOUS, or SOURCE_UNAVAILABLE. A numeric answer needs an exact metric row, requested period column, scale/currency and source span. A narrative answer needs a source quote and scope. Do not infer a missing value or treat an AI proposal as gold. If source and frozen corpus differ, record both separately. Human signoff and adjudication occur after independent reviews.
