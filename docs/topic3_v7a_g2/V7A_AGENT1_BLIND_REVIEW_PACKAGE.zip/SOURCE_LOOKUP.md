# Source lookup

Use the SEC URL and accession in SOURCE_FILINGS.csv, verify the filing identity, then navigate the original filing without consulting prior agent notes. Capture a new exact source locator and preserve the original period header and unit. Observe SEC request limits and the configured contact User-Agent.
