# V7A G2 independent source review

Review the 94 questions independently from original SEC filings using SOURCE_FILINGS.csv. Record the exact source locator, row or narrative span, fiscal column, unit and scale. Do not consult retrieval rankings, model answers, prior answer values, gold labels or another reviewer. Leave unsupported or ambiguous cases unresolved with a reason. This package contains no certified gold.
