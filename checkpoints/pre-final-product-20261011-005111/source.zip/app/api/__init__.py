"""FastAPI routers."""
