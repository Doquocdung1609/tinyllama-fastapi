"""Educational GenAI application backend."""
